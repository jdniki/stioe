$(document).ready(function(e){
    
    $('.nav-header a').on('click', function(){
        $('.active').removeClass('active');
        $(this).addClass('active');
        $('.wrapper').addClass('wrapper--hidden');
        $(''+($(this).attr('href'))).removeClass('wrapper--hidden');
    })
});